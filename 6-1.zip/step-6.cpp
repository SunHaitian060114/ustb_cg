// #include<iostream>
// using namespace std;
// int main()
// {
// 	cout << "(a)add account(d)deposit(w)withdraw(s)show(c)change day(n)next month(q)query(e)exit" << endl;
// 	cout << "2008 - 11 - 1       Total: 0        command >" << endl;
// 	return 0;
// }

#include <iomanip>
#include "AccountRecord.h"
#include "command_history.h"
#include <sstream>
std::string extractIdFromCommand(const std::string& command) {
    // 从命令中提取账户ID
    std::string id = command.substr(4, 8); // 假设ID位于命令的第5到第12字符
    return id;
}

double extractRateFromCommand(const std::string& command) {
    // 从命令中提取利率
    std::size_t pos = command.find_last_of(" ");
    return std::stod(command.substr(pos + 1));
}

int extractIndexFromCommand(const std::string& command) {
    // 从命令中提取账户索引
    std::size_t pos = command.find(" ");
    return std::stoi(command.substr(pos + 1, 1));  // 假设账户索引为命令的第二个部分
}

double extractAmountFromCommand(const std::string& command) {
    // 从命令中提取金额
    std::size_t pos1 = command.find(" ", 2);
    std::size_t pos2 = command.find(" ", pos1 + 1);
    return std::stod(command.substr(pos1 + 1, pos2 - pos1 - 1));
}

std::string extractDescriptionFromCommand(const std::string& command) {
    // 从命令中提取描述
    std::size_t pos = command.find_last_of(" ");
    return command.substr(pos + 1);
}

void executeCommand(const std::string& command, Date& date, std::vector<Account*>& accounts) {

    
    std::istringstream commandStream(command);  // 解析命令
    std::string action;
    commandStream >> action;  // 获取命令的第一部分（如 'a', 'd', 's' 等）
    
 if (action == "a") {  // 创建账户
    std::string type, id;
    double rate;
    commandStream >> type >> id >> rate;  // 获取账户类型、ID 和利率
    Account* account = nullptr;

    if (type == "s") {  // 储蓄账户
        account = new SavingsAccount(date, id, rate);
    } else if (type == "c") {  // 信用账户
        double credit, fee;
        commandStream >> credit >> fee;  // 获取信用额度和年费
        account = new CreditAccount(date, id, credit, rate, fee);
    }

    if (account != nullptr) {
        accounts.push_back(account);  // 添加账户到容器
    }

    // 创建账户时，检查并避免添加“interest”记录
    // 例如，如果创建账户时没有初始存款或取款操作，不生成零金额记录。
}
if (action == "d") {  // 存款
        int index;
        double amount;
        std::string desc;
        commandStream >> index >> amount;
        std::getline(commandStream, desc);  // 获取存款描述

        // 检查 index 是否有效，并且账户指针有效
        if (index >= 0 && index < accounts.size() && accounts[index] != nullptr) {
            accounts[index]->deposit(date, amount, desc);  // 执行存款操作
        } else {
            std::cout << "Invalid account index or null pointer!" << std::endl;
        }
    }
    else if (action == "w") {  // 取款
        int index;
        double amount;
        std::string desc;
        commandStream >> index >> amount;
        std::getline(commandStream, desc);  // 获取取款描述

        // 检查 index 是否有效，并且账户指针有效
        if (index >= 0 && index < accounts.size() && accounts[index] != nullptr) {
            accounts[index]->withdraw(date, amount, desc);  // 执行取款操作
        } else {
            std::cout << "Invalid account index or null pointer!" << std::endl;
        }
    }
    // 查询账户信息
    else if (action == "s") {  
        for (size_t i = 0; i < accounts.size(); i++) {
            std::cout << "[" << i << "] ";
            accounts[i]->show();  // 显示账户信息
            std::cout << std::endl;
        }
    }
    // 更改日期
    else if (action == "c") {  
        int day;
        commandStream >> day;
        if (day < date.Get_day()) {
            std::cout << "You cannot specify a previous day" << std::endl;
        } else if (day > date.getMaxDay()) {
            std::cout << "Invalid day" << std::endl;
        } else {
            date = Date(date.Get_year(), date.Get_month(), day);  // 修改日期
        }
    }
    //跳到下一个月
    else if (action == "n") {  
        if (date.Get_month() == 12)
            date = Date(date.Get_year() + 1, 1, 1);
        else
            date = Date(date.Get_year(), date.Get_month() + 1, 1);

        // 结算账户
        for (auto& account : accounts) {
            account->settle(date);
        }
    }

    // 查询账目
    else if (action == "q") {  
        Date date1 = Date::read();
        Date date2 = Date::read();
        Account::query(date1, date2);  // 执行查询
    }
    // 退出程序
    else if (action == "e") {  
        std::cout << "Exiting program..." << std::endl;
    }
    // else {
    //     std::cout << "Unknown command!" << std::endl;
    // }
}



struct deleter {

template <class T> void operator () (T* p) { delete p; }

};//自定义删除器，可删除指针所指向的内存



int main() {

        char cmd = ' ';

Date date(2008, 11, 1);//起始日期

vector<Account *> accounts;//创建账户数组，元素个数为0
std::vector<std::string> commands = CommandHistoryManager::loadCommands();

for (const auto& command : commands) {
    if (CommandHistoryManager::isValidCommand(command)) {
        executeCommand(command, date, accounts);  // 传递date和accounts
    }
}
cout << "(a)add account (d)deposit (w)withdraw (s)show (c)change day (n)next month (q)query (e)exit" << endl;

do {
    // 显示日期和总金额

    date.show();
        cout << "Total: " << std::fixed << std::setprecision(1) << Account::getTotal() << "\tcommand> ";

    // 逐行读取命令
        std::string newCommand;
        std::getline(std::cin, newCommand);  // 读取整行命令

        // 判断输入是否为空
        if (!newCommand.empty()) {
            std::istringstream commandStream(newCommand);  // 使用 stringstream 来处理输入命令
            std::string command;

            while (commandStream >> command) {  // 遍历每个空格分隔的命令
                CommandHistoryManager::saveCommand(command);  // 保存命令到历史记录
                if (CommandHistoryManager::isValidCommand(command)) {
                    executeCommand(command, date, accounts);  // 执行命令
                }
            }
        }
    
    // std::string newCommand;
    // std::getline(std::cin, newCommand);  // 读取整行命令
    // std::istringstream commandStream(newCommand);  // 使用 stringstream 来处理空格分隔的命令
    // std::string command;

    // while (commandStream >> command) {  // 遍历每个空格分隔的命令
    //     CommandHistoryManager::saveCommand(command);  // 保存命令到历史记录
    //     if (CommandHistoryManager::isValidCommand(command)) {
    //         executeCommand(command, date, accounts);  // 执行命令
    //     }
    // }



    // 解析并执行命令
    switch (newCommand[0]) {  // 根据命令的首字母处理
        case 'a': // 创建账户
            {
                char type;
                std::string id;
                std::cin >> type >> id;
                Account* account;
                
                if (type == 's') {  // 创建储蓄账户
                    double rate;
                    std::cin >> rate;
                    account = new SavingsAccount(date, id, rate);
                } else {  // 创建信用账户
                    double credit, rate, fee;
                    std::cin >> credit >> rate >> fee;
                    account = new CreditAccount(date, id, credit, rate, fee);
                }
                accounts.push_back(account);
            }
            break;

        case 'd': // 存款
            {
                int index;
                double amount;
                std::string desc;
                std::cin >> index >> amount;
                std::cin.ignore();  // 忽略换行符
                std::getline(std::cin, desc);
                accounts[index]->deposit(date, amount, desc);  // 执行存款
            }
            break;

        case 'w': // 取款
            {
                int index;
                double amount;
                std::string desc;
                std::cin >> index >> amount;
                std::cin.ignore();  // 忽略换行符
                std::getline(std::cin, desc);
                accounts[index]->withdraw(date, amount, desc);  // 执行取款
            }
            break;

        case 's': // 查询账户
            for (size_t i = 0; i < accounts.size(); i++) {
                cout << "[" << i << "] ";
                accounts[i]->show();  // 查询账户信息
                cout << endl;
            }
            break;

        case 'c': // 改变日期
            {
                int day;
                std::cin >> day;
                if (day < date.Get_day()) {
                    cout << "You cannot specify a previous day" << endl;
                } else if (day > date.getMaxDay()) {
                    cout << "Invalid day" << endl;
                } else {
                    date = Date(date.Get_year(), date.Get_month(), day);  // 修改日期
                }
            }
            break;

        case 'n': // 下一个月
            if (date.Get_month() == 12)
                date = Date(date.Get_year() + 1, 1, 1);
            else
                date = Date(date.Get_year(), date.Get_month() + 1, 1);

            // 结算账户
            for (auto iter = accounts.begin(); iter != accounts.end(); ++iter) {
                (*iter)->settle(date);
            }
            break;

        case 'q': // 查询账目
            {
                Date date1 = Date::read();
                Date date2 = Date::read();
                Account::query(date1, date2);  // 执行查询
            }
            break;

        case 'e': // 退出程序
            break;

        default:
            cout << "Unknown command!" << endl;
            break;
    }

} while (cmd != 'e');


for_each(accounts.begin(), accounts.end(), deleter());

return 0;

}